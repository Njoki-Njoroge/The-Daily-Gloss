
import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({ children, onClick, variant = 'primary', className = '' }) => {
  const baseStyles = "px-6 py-2 rounded-full font-semibold tracking-wide transition-all duration-300 transform hover:scale-105 active:scale-95 shadow-sm";
  
  const variants = {
    primary: "bg-pink-500 text-white hover:bg-pink-600 border-none",
    secondary: "bg-lime-300 text-lime-900 hover:bg-lime-400 border-none",
    outline: "border-2 border-pink-500 text-pink-500 bg-transparent hover:bg-pink-50"
  };

  return (
    <button onClick={onClick} className={`${baseStyles} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
};
