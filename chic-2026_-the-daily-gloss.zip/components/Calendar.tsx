
import React, { useState } from 'react';
import { MONTHS } from '../constants';

interface CalendarProps {
  onSelectDate: (date: Date) => void;
  hasEntry: (date: string) => boolean;
}

export const Calendar: React.FC<CalendarProps> = ({ onSelectDate, hasEntry }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const year = 2026;

  const getDaysInMonth = (month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const days = getDaysInMonth(currentMonth);
  const startDay = getFirstDayOfMonth(currentMonth);

  return (
    <div className="max-w-4xl mx-auto p-6 md:p-12 bg-white rounded-[3rem] shadow-2xl border-4 border-lime-200">
      <div className="flex justify-between items-center mb-12">
        <button 
          onClick={() => setCurrentMonth(prev => Math.max(0, prev - 1))}
          className="text-pink-400 hover:text-pink-600 transition-colors text-3xl font-serif-chic"
        >
          &larr;
        </button>
        <div className="text-center">
          <h2 className="text-5xl font-serif-chic text-pink-600 mb-2 italic">{MONTHS[currentMonth]}</h2>
          <span className="text-lime-600 font-bold tracking-widest">EST. 2026</span>
        </div>
        <button 
          onClick={() => setCurrentMonth(prev => Math.min(11, prev + 1))}
          className="text-pink-400 hover:text-pink-600 transition-colors text-3xl font-serif-chic"
        >
          &rarr;
        </button>
      </div>

      <div className="grid grid-cols-7 gap-4">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
          <div key={d} className="text-center font-bold text-gray-400 text-xs mb-4 uppercase">{d}</div>
        ))}
        
        {Array.from({ length: startDay }).map((_, i) => (
          <div key={`empty-${i}`} />
        ))}

        {Array.from({ length: days }).map((_, i) => {
          const day = i + 1;
          const date = new Date(year, currentMonth, day);
          const dateStr = date.toISOString().split('T')[0];
          const hasLog = hasEntry(dateStr);

          return (
            <button
              key={day}
              onClick={() => onSelectDate(date)}
              className={`
                aspect-square flex flex-col items-center justify-center rounded-2xl transition-all duration-300 transform hover:scale-105 group relative
                ${hasLog ? 'bg-lime-100 text-lime-800 border-2 border-lime-300 shadow-md' : 'bg-pink-50 text-pink-400 hover:bg-pink-100'}
              `}
            >
              <span className="text-lg font-serif-chic font-bold">{day}</span>
              {hasLog && (
                <div className="absolute -top-2 -right-2 text-xl animate-bounce">✨</div>
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-12 text-center">
        <p className="font-cursive text-2xl text-pink-400 opacity-80">"Style is a way to say who you are without having to speak."</p>
      </div>
    </div>
  );
};
