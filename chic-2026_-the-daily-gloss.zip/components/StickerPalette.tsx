
import React from 'react';
import { STICKERS } from '../constants';

interface StickerPaletteProps {
  onSelect: (emoji: string) => void;
  selectedStickers: string[];
  onRemove: (index: number) => void;
}

export const StickerPalette: React.FC<StickerPaletteProps> = ({ onSelect, selectedStickers, onRemove }) => {
  return (
    <div className="bg-white p-4 rounded-3xl shadow-lg border border-pink-100 mt-6">
      <h3 className="font-serif-chic text-pink-600 mb-3 text-lg">Finishing Touches</h3>
      
      <div className="flex flex-wrap gap-3 mb-6">
        {STICKERS.map((sticker) => (
          <button
            key={sticker.id}
            onClick={() => onSelect(sticker.emoji)}
            className="text-2xl p-2 hover:bg-lime-100 rounded-xl transition-colors transform hover:scale-110"
            title={sticker.name}
          >
            {sticker.emoji}
          </button>
        ))}
      </div>

      <div className="border-t border-pink-50 pt-4">
        <p className="text-xs uppercase tracking-widest text-gray-400 mb-3">Applied Accents</p>
        <div className="flex flex-wrap gap-2">
          {selectedStickers.length === 0 && <span className="text-gray-300 italic text-sm">No accents added yet...</span>}
          {selectedStickers.map((emoji, idx) => (
            <div 
              key={idx} 
              onClick={() => onRemove(idx)}
              className="relative group cursor-pointer bg-pink-50 rounded-full w-10 h-10 flex items-center justify-center text-xl"
            >
              {emoji}
              <span className="absolute -top-1 -right-1 bg-red-400 text-white rounded-full w-4 h-4 text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">×</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
