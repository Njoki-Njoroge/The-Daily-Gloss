
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateEditorial = async (content: string, mood: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Transform the following daily log into a luxury magazine editorial snippet. 
      It should sound chic, high-end, and sophisticated. 
      User's log: "${content}"
      Current Mood: ${mood}
      
      Format the output as a JSON object with two fields: 
      "headline" (a catchy, chic magazine title) and 
      "editorial" (the sophisticated body text, max 150 words).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING },
            editorial: { type: Type.STRING },
          },
          required: ["headline", "editorial"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      headline: "The Unspoken Glamour",
      editorial: "Today unfolded with an effortless grace that only the truly chic can command. Every moment was a curated experience in modern elegance."
    };
  }
};
